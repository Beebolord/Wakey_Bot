

import pandas as pd
if __name__ == "__main__":
    df = pd.read_csv('Assignment.csv')
    df['total_games'] = (df['Summer_Games.Game_Count']+df['Winter_Games.Game_Count'])
    df['Gold_Combined_Total'] = (df['Summer_Games.Gold']+df['Winter_Games.Gold'])
    df['Silver_Combined_Total'] = (df['Summer_Games.Silver']+df['Winter_Games.Silver'])
    df['Bronze_Combined_Total'] = (df['Summer_Games.Bronze']+df['Winter_Games.Bronze'])
    df['Combined_total'] = (df['Gold_Combined_Total']+df['Silver_Combined_Total']+df['Bronze_Combined_Total'])
    pd.set_option('display.max_rows', None)
    pd.set_option('display.max_columns', None)
    print(df)